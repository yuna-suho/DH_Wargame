import requests
import base64
import json

URL = "http://host3.dreamhack.games:23373/"

def get_token(user_id, user_pw):
    params = {
        "id": user_id,
        "pw": user_pw
    }
    res = requests.get(f"{URL}/login", params=params).json()
    if res['status'] == 'success':
        return res['result']['token']
    return None

def get_article(idx):
    res = requests.get(f"{URL}/gb/{idx}").json()
    if res['status'] == 'success':
        return res['result']['article']
    return None

def get_all_articles():
    res = requests.get(f"{URL}/gb").json()
    if res['status'] == 'success':
        return res['result']['articles']
    return None

def secure_decrypt(e_data, token, sig):
    params = {
        "e_data": e_data,
        "token": token,
        "sig": sig
    }
    res = requests.get(f"{URL}/secure/decrypt", params=params).json()
    print(res)
    if res['status'] == 'success':
        return res['result']['content']
    return None

def secure_secret(password):
    res = requests.get(
        f"{URL}/secure/secret",
        params={"password": password}
    ).json()

    if res['status'] == 'success':
        return res['result']['secret']
    return None

def padding_oracle(ct, token, sig):
    e_data = base64.b64encode(ct).decode('latin-1')

    params = {
        "e_data": e_data,
        "token": token,
        "sig": sig
    }

    res = requests.get(f"{URL}/secure/decrypt", params=params).json()
    try:
        message = res["result"]["message"]
        return message != "ValueError"
    except ValueError:
        return True

def decrypt_block(prefix, prev_block, target_block, token, sig):
    intermediate = bytearray(16)

    for pad in range(1, 17):
        crafted = bytearray(prev_block)

        for j in range(1, pad):
            crafted[-j] = intermediate[-j] ^ pad

        pos = 16 - pad
        found = False

        for guess in range(256):
            crafted[pos] = guess

            test_cipher = (
                prefix +
                bytes(crafted) +
                target_block
            )

            if padding_oracle(test_cipher, token, sig):
                if pad == 1:
                    check = bytearray(crafted)
                    check[-2] ^= 1

                    confirm_cipher = (
                        prefix +
                        bytes(check) +
                        target_block
                    )

                    if not padding_oracle(
                        confirm_cipher, token, sig
                    ):
                        continue

                intermediate[pos] = guess ^ pad
                found = True
                break

        if not found:
            raise Exception(
                f"Recover Failed: position={pos}, padding={pad}"
            )

        print(
            f"[+] position={pos}, "
            f"intermediate=0x{intermediate[pos]:02x}"
        )

    return bytes(intermediate)


def decrypt_admin_article(admin_e_data):

    ciphertext = base64.b64decode(admin_e_data)

    blocks = [
        ciphertext[i:i+16]
        for i in range(0, len(ciphertext), 16)
    ]

    print("[*] Total blocks:", len(blocks))
    plaintext = bytearray(b'{"content": "The')

    for i in range(1, len(blocks)):

        prefix = b''.join(blocks[:i-1])
        prev_block = blocks[i-1]
        target_block = blocks[i]

        print(f"\n[*] Decrypting block {i+1}")

        intermediate = decrypt_block(
            prefix,
            prev_block,
            target_block,
            guest_token,
            admin_sig
        )

        plain_block = bytes(
            a ^ b
            for a, b in zip(intermediate, prev_block)
        )

        plaintext.extend(plain_block)

        print("[+] Plain block:", plain_block.hex())

    pad = plaintext[-1]
    if 1 <= pad <= 16 and plaintext[-pad:] == bytes([pad]) * pad:
        plaintext = plaintext[:-pad]
    else:
        raise Exception("PKCS#7 padding verification failed")

    return bytes(plaintext)


if __name__ == "__main__":
    # prepare data for attack
    guest_token = get_token('guest', 'guest')
    print("guest's token:", guest_token)

    admin_article = get_article(1)
    admin_e_data = admin_article['enc_data']
    print("admin's encrypted data:", admin_e_data)
    admin_sig = admin_article['sig']
    print("admin's signature:", admin_sig)
    print('----------------------------------------------')

    recovered = decrypt_admin_article(admin_e_data)

    print("\n[+] Recovered plaintext:")
    print(recovered.decode('latin-1'))
    print()

    password = json.loads(recovered.decode('latin-1'))['content'].split('is: ')[1].split('", ')[0]

    print(secure_secret(password))

# {"content": "The password is: p45$W0Rd", "author": "admin"}

# DH{0cfeeb1ded546cb87e43caf2df2c6ec078c559b5}