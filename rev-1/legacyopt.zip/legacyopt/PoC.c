#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void encrypt(char *output, char *input, int size) {
    unsigned char xor_key[8] = {0x88, 0x33, 0x22, 0x55, 0x77, 0x11, 0x44, 0x66};

    for (int i = 0; i < size; i++) {
        output[i] = input[i] ^ xor_key[(size - i) % 8];
    }
}

int main() {
    char *output = "220c6a33204455fb390074013c4156d704316528205156d70b217c14255b6ce10837651234464e";
    char tmp[104];
    char input[104];

    int length = strlen(output) / 2;
    for (int i = 0; i < length; i++) {
        sscanf(output + i * 2, "%2hhx", &tmp[i]);
    }

    encrypt(input, tmp, length);

    printf("%s\n", input);

    return 0;
}