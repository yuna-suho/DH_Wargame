#include <stdio.h>
#include <stdlib.h>

int main() {
    FILE *enc_file;
    FILE *flag_file;
    int local_2c;
    size_t sVar1;
    size_t local_2d;

    char data[] = "\xde\xad\xbe\xef";
    
    enc_file = fopen("encrypted", "rb");
    if (enc_file == NULL) {
        puts("fopen() error");
        exit(1);
    }

    flag_file = fopen("flag.png", "wb");
    if (flag_file == NULL) {
        puts("fopen() error");
        fclose(enc_file);
        exit(1);
    }

    local_2c = 0;
    while (true) {
        sVar1 = fread(&local_2d, 1, 1, enc_file);
        if (sVar1 != 1) break;
        local_2d = (local_2d - 0x13) ^ data[local_2c % 4];
        fwrite(&local_2d, 1, 1, flag_file);
        local_2c = local_2c + 1;
    }
    
    fclose(flag_file);
    fclose(enc_file);
    
    return 0;
}