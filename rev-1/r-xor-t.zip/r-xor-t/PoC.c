#include <stdio.h>

int main() {
    char* text = "C@qpl==Bppl@<=pG<>@l>@Blsp<@l@AArqmGr=B@A>q@@B=GEsmC@ArBmAGlA=@q";
    char tmp;
    printf("DH{");
    for (int i = 0; i < 0x40; i++) {
        tmp = text[0x3f - i] ^ 3;
        tmp = tmp & 0x7F;
        tmp = tmp - 0xd;
        printf("%c", tmp);
    }
    puts("}");

    return 0;
}