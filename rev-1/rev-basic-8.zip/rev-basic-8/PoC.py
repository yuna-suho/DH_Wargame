data = bytes.fromhex("AC F3 0C 25 A3 10 B7 25 16 C6 B7 BC 07 25 02 D5 C6 11 07 C5 00 00 00 00 00 00 00 00 00 00 00 00")

result = []

z = pow(-5, -1, 256)

for i in range(0x15):
    result.append((z * data[i]) & 0xFF)

print(bytes(result))
