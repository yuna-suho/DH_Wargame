data = bytes.fromhex("52 DF B3 60 F1 8B 1C B5 57 D1 9F 38 4B 29 D9 26 7F C9 A3 E9 53 18 4F B8 6A CB 87 58 5B 39 1E 00")

result = []

def ror8(value, n):
    return ((value >> n) | (value << (8 - n))) & 0xFF

for i in range(0x1F):
    tmp = data[i] ^ i
    result.append(ror8(tmp, i & 7))

print(bytes(result))
