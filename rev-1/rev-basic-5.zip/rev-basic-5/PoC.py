data = bytes.fromhex("AD D8 CB CB 9D 97 CB C4 92 A1 D2 D7 D2 D6 A8 A5 DC C7 AD A3 A1 98 4C 00 00 00 00 00 00 00 00 00")

result = []
a1 = 0

for i in range(0x17, -1, -1):
    a1 = data[i] - a1
    result.append(a1)

result.reverse()
result = bytes(result)

print(result)
