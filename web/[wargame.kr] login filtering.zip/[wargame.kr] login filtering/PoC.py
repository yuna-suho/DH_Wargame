import requests, re

url = 'http://host3.dreamhack.games:13831'

res = requests.post(url, data={'id': 'Guest', 'ps': 'guest'})
print(re.search(r'DH\{[^>]*\}', res.text).group(0))
