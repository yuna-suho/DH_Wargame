import requests, re

url = 'http://host3.dreamhack.games:11374'

res = requests.get(f'{url}/flag.txt')
print(res.text)
